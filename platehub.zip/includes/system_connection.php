<?php
$link = mysql_connect('localhost', 'root', '') or die();
mysql_select_db('platehub', $link);
?>