

<footer>
	<div class="socFtr">
    	<ul>
        	<li><a href="#" target="_blank"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#" target="_blank"><i class="fa fa-google-plus"></i></a></li>
            <li><a href="#" target="_blank"><i class="fa fa-linkedin"></i></a></li>
        </ul>
    </div>
	<div class="page">
    	 All rights Reserved <?php echo date('Y');?> © mywebsite.com | develoved by <a href="http://webontechnology.com/" target="_blank">webontechnology.com</a>
    </div>
</footer>

<script type="text/javascript" src="js/for_html.js"></script>
<script src="js/responsiveslides.min.js"></script>
<script src="js/jquery.form.js"></script>
<script src="js/custom.js"></script>


<script>

    $(function () {

      $("#slider2").responsiveSlides({
        auto: true,
        pager: true,
        speed: 300,
        //maxwidth: 540,
		
      });

    });
  </script>
</body>
</html>
