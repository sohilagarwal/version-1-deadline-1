<?php include_once "includes/header.php";?>
<div class="inrHdr" style="background:url(images/bg1.jpg) no-repeat center center;">
<div class="page">

    <h1>LEGAL</h1>
    
    <div class="brdkm">
        <a href="#">home</a> / <span>legal</span>
    </div>

</div>
</div>


<div class="minPge">
<div class="page">

<div class="pgeHdr">
	<h1>LEGAL</h1>
    
</div>



<DIV class="abutBX">
	<div class="abtIn">
    
<div class="abTxt">

<h2>Demo Heading Here:</h2>
<p>
<i class="fa fa-circle"></i> Connect local farmers, buyers and distributors<br />
<i class="fa fa-circle"></i> Promote and increase the number of Healthy corner stores in “food deserts” <br />
<i class="fa fa-circle"></i> Create a space to leverage alternative food delivery and distribution options<br />
<i class="fa fa-circle"></i> Locate farmer’s market in your area<br />
<i class="fa fa-circle"></i> Request mobile farms to sell in your neighborhood <br />
<i class="fa fa-circle"></i> Mobilize and facilitate the organization of local food hubs <br />
<i class="fa fa-circle"></i> Identify untapped market potential for food retail expansion in underserved areas
</p>

</div> 

   
    
    </div>
</DIV>


</div>
</div>
<?php include_once "includes/footer.php";?>